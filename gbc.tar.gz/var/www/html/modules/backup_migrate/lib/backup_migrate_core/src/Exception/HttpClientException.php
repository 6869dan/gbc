<?php

namespace BackupMigrate\Core\Exception;

/**
 * Class HttpClientException
 * @package BackupMigrate\Core\Exception
 */
class HttpClientException extends BackupMigrateException {}
